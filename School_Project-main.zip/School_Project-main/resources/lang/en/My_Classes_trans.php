<?php

return [

    'title_page' => 'Classes',
    'List_classes' => 'List Classes',
    'add_class' => 'add class',
    'edit_class'=> 'edit class',
    'delete_class'=> 'delete class',
    'Warning_Grade'=> 'Are you sure?',
    'submit' => 'submit',
    'Name_class_ar'=>'Name_class ar',
    'Name_class'=>'Name class',
    'Name_class_en'=>'Name class en',
    'Name_Grade'=>'Name Grade',
    'add_row'=>'add row',
    'delete_row'=>'Delete row',
    'Processes'=>'Processes',
    'Edit'=>'Edit',
    'Delete'=>'Delete',
    'Close' => 'Close',
    'delete_Class_Error'=>'The Class cannot be Deleted because it contains Sections',
    'Warning_Grade'=> "Are you sure?",
    'Search_By_Grade'=> 'Search By Grade Name',
    'delete_checkbox'=> 'Delete Selected',
    'choose'=>'please choose an element to remove',
    'Search'=>'Search'





];