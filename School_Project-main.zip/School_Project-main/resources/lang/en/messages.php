<?php

return [
    'success'=>'Data has been saved successfully',
    'Update'=>'Data has been Updated successfully',
    'Delete'=>'Data has been Deleted successfully',
    'exist'=>'This field already exists!',



    // ---------
    'relation' => 'You can\'t delete this grade because there is a relationship with classes' ,
    'error' => 'No students selected',


];