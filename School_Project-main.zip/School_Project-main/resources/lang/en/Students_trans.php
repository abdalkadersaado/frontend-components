<?php

return [

    'personal_information' => 'personal information',
    'name' => 'Name',
    'name_ar' => 'name_ar',
    'name_en' => 'name_en',
    'email' => 'email',
    'password' => 'password',
    'gender' => 'gender',
    'Nationality' => 'Nationality',
    'blood_type' => 'blood_type',
    'Date_of_Birth' => 'Date_of_Birth',
    'Student_information' => 'Student information',
    'Grade' => 'Grade',
    'classrooms' => 'classrooms',
    'section' => 'section',
    'parent' => 'parent',
    'academic_year' => 'academic_year',
    'Processes' => 'Processes',
    'submit' => 'submit',
    'Close' => 'Close',
    'Attachments' => 'Attachments',
    'Student_details' => 'Student Details',
    'Deleted_Student' => 'Delete student data',
    'Deleted_Student_tilte' => 'Are you sure to delete the student ?',
    'Delete_attachment' => 'Delete_attachment',
    'Delete_attachment_tilte' => 'Are you sure to delete the attachment?',
    'filename' => 'filename',
    'created_at' => 'created_at',
    'Download' => 'Download',
    'delete' => 'Delete',



    // ---------

    "old"=>"old grade",
    "new"=>"new grade",

];