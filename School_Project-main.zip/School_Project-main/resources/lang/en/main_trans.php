<?php

return [

  'Dashboard'=>'Dashboard',
  'Dashboard_page'=>'Dashboard',
  'Main_title' => 'Backend School Management Program by Mohamed Salah',
  'Programname' => 'Backend School Management Program by Mohamed Salah',
  'change_language'=>'language',
  'Grades'=>'Grades',
  'Grades_list'=>'Grades List',
  'classes'=>'Classes',
  'List_classes' => 'List Classes',
  'sections'=>'Sections',
  'List_sections'=>'List Sections',
  'students'=>'Students',
  'add_student'=>'Add student',
  'list_students'=>'list of Students',
  'Students_Promotions'=>'Students Promotions',
  'Student_information'=>'Information Students',
  'add_Promotion'=>'add Promotion',
  'list_Promotions'=>'Promotions List',
  'Students_upgrade'=>'Students Upgrade',
  'Graduate_students'=>'Graduate Students',
  'add_Graduate'=>'add Graduate ',
  'list_Graduate'=>'list of Graduate ',
  'Teachers'=>'Teachers',
  'List_Teachers' => 'List Teachers',
  'Parents'=>'Parents',
  'Add_Parent'=>'Add Parent',
  'List_Parents'=>'List Parents',
  'Accounts'=>'Accounts',
  'Attendance'=>'Attendance',
  'Exams'=>'Exams',
  'library'=>'Library',
  'Onlineclasses'=>'Online classes',
  'Settings'=>'Settings',
  'Users'=>'Users',
  'Copyright' => 'Copyright',
  'Name_Programer' => 'SamirGamal MoraSoft All Rights Reserved',



      // ----------------

      'Promotion_managment' =>'Promotion_managment',
      'subject_list'=>'subjects list',
      'subject'=>'subjects',
      'study_fees'=>"study fees",
      'Invoices'=>"Invoices",
      'receipt'=>'receipt',
      'Exclude_fees'=>'Exclude fees',
      'Bills_of_exchange'=>'Bills of exchange',
      'Exams_list'=>'Exams list',
      'Quizes_list'=>'Quizes_list',
      'Books_list'=>'Books list',
      'Calendar'=>'Calendar',
      'add_events'=>'add events ',
      'Indirect_communication_with_Zoom'=>'Indirect communication with Zoom',


];