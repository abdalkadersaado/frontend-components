(function () {
    function clickHandler(event) {
        var button = event.target.closest('.btn');
        if (button) {
            var butonCover = button.closest('.buton-cover');
            if (butonCover) {
                butonCover.classList.toggle('is_active');
            }
        }
    }

    var buttons = document.querySelectorAll('.btn');
    buttons.forEach(function (button) {
        button.addEventListener('click', clickHandler);
    });
})();
