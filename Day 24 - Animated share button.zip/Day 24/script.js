document.querySelectorAll('.share-button').forEach(function (button) {
    button.addEventListener('click', function () {
        this.classList.add('open');
    });
});

document.querySelectorAll(".share-items").forEach(function (item) {
    item.addEventListener('mousedown', function (event) {
        let startX = event.clientX;
        let startScrollLeft = this.scrollLeft;

        item.addEventListener('mousemove', function (event) {
            let deltaX = event.clientX - startX;
            this.scrollLeft = startScrollLeft - deltaX;
        });

        item.addEventListener('mouseup', function () {
            item.removeEventListener('mousemove');
        });
    });
});

document.querySelectorAll(".share-item").forEach(function (item) {
    item.addEventListener('click', function () {
        document.querySelectorAll('.share-button').forEach(function (button) {
            button.classList.add('shared');
            setTimeout(function () {
                button.classList.add('thankyou');
            }, 800);
            setTimeout(function () {
                button.classList.remove('open', 'shared', 'thankyou');
            }, 2500);
        });
    });
});
