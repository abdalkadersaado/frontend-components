document.getElementById("hue").oninput = function (e) {
    document.firstElementChild.style.setProperty('--hue', e.target.value);
};