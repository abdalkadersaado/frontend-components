<template>
    <aboutView/>
  </template>

  <script setup>
    import aboutView from '@/components/AboutPage.vue'
  </script>
