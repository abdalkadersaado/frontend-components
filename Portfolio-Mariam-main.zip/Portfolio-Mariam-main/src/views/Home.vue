<template>
  <homeView/>
</template>

<script setup>
  import homeView from '@/components/HomePage.vue'
</script>
