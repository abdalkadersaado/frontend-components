<template>
<skillsView/>
</template>

  <script setup>
import skillsView from '@/components/SkillsPage.vue'
</script>