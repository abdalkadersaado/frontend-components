<template>
    <contactMe/>
  </template>

  <script setup>
    import contactMe from '@/components/ContactMe.vue'
  </script>
