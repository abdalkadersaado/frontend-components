<template>
    <projectView/>
  </template>

  <script setup>
    import projectView from '@/components/ProjectPage.vue'
  </script>
