<template>
    <v-container class="fill-height bg-about" fluid>
        <v-responsive class="fill-height">
            <!-- <h1 class="mt-16">SKILLS</h1> -->

<v-row align="center" justify="center" class=" fill-height">
    <v-col md="8" cols="12">
    <h1 class="mt-6 text-h4 text-indigo-lighten-1" data-aos="fade-down" data-aos-duration="1500">SKILL SET</h1>
    <h3 class="mb-10 text-h6" data-aos="fade-down" data-aos-duration="1000">Exploring the diverse range of skills I've acquired and developed:</h3>

    <h4 class="mt-6 text-h5 text-indigo-lighten-3" data-aos="fade-right" data-aos-duration="2000">Design Principles</h4>
    <p class="text-h6" data-aos="fade-right" data-aos-duration="3000">Highly skilled at crafting visually appealing designs using fundamental principles of color theory, typography, layout composition, and balance to captivate viewers and convey messages effectively.</p>

    <h4 class="mt-6 text-h5 text-indigo-lighten-3" data-aos="fade-right" data-aos-duration="2000">Responsive Layouts</h4>
    <p class="text-h6" data-aos="fade-right" data-aos-duration="3000">crafting adaptable layouts for diverse devices, ensuring optimal user experience by seamlessly adjusting design elements and content to different screen sizes.</p>

    <h4 class="mt-6 text-h5 text-indigo-lighten-3" data-aos="fade-right" data-aos-duration="2000">Interaction Design</h4>
    <p class="text-h6" data-aos="fade-right" data-aos-duration="3000">creating intuitive and seamless interactions for user-friendly experiences, harmonizing aesthetics and usability.</p>

    <h4 class="mt-8 text-h5 text-indigo-lighten-3"  data-aos="fade-right" data-aos-duration="2000">Prototyping</h4>
    <p class="text-h6" data-aos="fade-right" data-aos-duration="3000">translating concepts into interactive prototypes for testing and refinement, ensuring functional and engaging end products</p>
    </v-col>
<v-col md="8" cols="12">
    <h1 class="text-indigo-lighten-1 text-h4 mt-md-16 pt-4" data-aos="fade-up" data-aos-duration="1500">PROGRAMMING <span class="mdi mdi-xml "></span></h1>
    <v-row class="mb-16 mt-8" data-aos="fade-up" data-aos-duration="3000">
<v-col md="3" cols="6" class="text-h6"><span class="mdi mdi-language-html5 text-indigo-lighten-1 text-h5"></span>HTML5</v-col>
<v-col md="3" cols="6" class="text-h6"><span class="mdi mdi-language-css3 text-indigo-lighten-1 text-h5"></span>CSS3</v-col>
<v-col md="3" cols="6" class="text-h6"><span class="mdi mdi-language-javascript text-indigo-lighten-1 text-h5"></span>Javascript</v-col>
<v-col md="3" cols="6" class="text-h6"><span class="mdi mdi-vuejs text-indigo-lighten-1 text-h5"></span>Vue 3</v-col>
<v-col md="3" cols="6" class="text-h6"><span class="mdi mdi-bootstrap text-indigo-lighten-1 text-h5"></span>Bootstrap</v-col>
<v-col md="3" cols="6" class="text-h6"><span class="mdi mdi-bulma text-indigo-lighten-1 text-h5"></span>Bulma</v-col>
<v-col md="3" cols="6" class="text-h6"><span class="mdi mdi-vuetify text-indigo-lighten-1 text-h5"></span>Vuetify</v-col>
<v-col md="3" cols="6" class="text-h6"><span class="mdi mdi-github text-indigo-lighten-1 text-h5"></span>GitHub</v-col>
    </v-row>

</v-col>




            </v-row>
        </v-responsive>
    </v-container>
</template>

<script setup></script>