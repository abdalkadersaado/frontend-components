<!-- <template>
    <h1 class="text-center mt-16 text-indigo-lighten-1 ">MY PROJECTS</h1>
    <div class="text-center my-10 ">
        <v-btn variant="elevated" class="mx-4 bg-indigo-lighten-1" rounded="lg"  size="large">ALL</v-btn>
        <v-btn variant="elevated" class="mx-4 bg-indigo-lighten-1" rounded="lg" size="large">Pure</v-btn>
        <v-btn variant="elevated" class="mx-4 bg-indigo-lighten-1" rounded="lg" size="large">Vue 3</v-btn>

    </div>
    <v-row class="my-16 w-75 mx-auto" align="center" justify="center" >
      <v-col md="3" cols="12">
        <v-hover v-slot="{ isHovering, props }">
            <v-card
              class="mx-auto"
              max-width="344"
              v-bind="props"
            >
              <v-img src="https://cdn.vuetifyjs.com/images/cards/forest-art.jpg"></v-img>
              <v-card-text>
                <h2 class="text-h6 text-primary">
                  Magento Forests
                </h2>
              </v-card-text>
              <v-overlay
                :model-value="isHovering"
                class="align-center justify-center"
                scrim="#036358"
                contained
              >
                <v-btn variant="flat">See more info</v-btn>
              </v-overlay>
            </v-card>
                 </v-hover>
      </v-col>
       <v-col md="3" cols="12">
           <v-hover v-slot="{ isHovering, props }">
            <v-card
              class="mx-auto"
              max-width="344"
              v-bind="props"
            >
              <v-img src="https://cdn.vuetifyjs.com/images/cards/forest-art.jpg"></v-img>
              <v-card-text>
                <h2 class="text-h6 text-primary">
                  Magento Forests
                </h2>
              </v-card-text>
              <v-overlay
                :model-value="isHovering"
                class="align-center justify-center"
                scrim="#036358"
                contained
              >
                <v-btn variant="flat">See more info</v-btn>
              </v-overlay>
            </v-card>
                 </v-hover>
       </v-col>
       <v-col md="3" cols="12">
        <v-hover v-slot="{ isHovering, props }">
            <v-card
              class="mx-auto"
              max-width="344"
              v-bind="props"
            >
              <v-img src="https://cdn.vuetifyjs.com/images/cards/forest-art.jpg"></v-img>
              <v-card-text>
                <h2 class="text-h6 text-primary">
                  Magento Forests
                </h2>
              </v-card-text>
              <v-overlay
                :model-value="isHovering"
                class="align-center justify-center"
                scrim="#036358"
                contained
              >
                <v-btn variant="flat">See more info</v-btn>
              </v-overlay>
            </v-card>
                 </v-hover>
       </v-col>
       <v-col md="3" cols="12">
        <v-hover v-slot="{ isHovering, props }">
        <v-card
          class="mx-auto"
          max-width="344"
          v-bind="props"
        >
          <v-img src="https://cdn.vuetifyjs.com/images/cards/forest-art.jpg"></v-img>
          <v-card-text>
            <h2 class="text-h6 text-primary">
              Magento Forests
            </h2>
          </v-card-text>
          <v-overlay
            :model-value="isHovering"
            class="align-center justify-center"
            scrim="#036358"
            contained
          >
            <v-btn variant="flat">See more info</v-btn>
          </v-overlay>
          </v-card>
         </v-hover>
       </v-col>
       <v-col md="3" cols="12">
        <v-hover v-slot="{ isHovering, props }">
        <v-card
          class="mx-auto"
          max-width="344"
          v-bind="props"
        >
          <v-img src="https://cdn.vuetifyjs.com/images/cards/forest-art.jpg"></v-img>
          <v-card-text>
            <h2 class="text-h6 text-primary">
              Magento Forests
            </h2>
          </v-card-text>
          <v-overlay
            :model-value="isHovering"
            class="align-center justify-center"
            scrim="#036358"
            contained
          >
            <v-btn variant="flat">See more info</v-btn>
          </v-overlay>
          </v-card>
         </v-hover>
       </v-col>
       <v-col md="3" cols="12">
        <v-hover v-slot="{ isHovering, props }">
        <v-card
          class="mx-auto"
          max-width="344"
          v-bind="props"
        >
          <v-img src="https://cdn.vuetifyjs.com/images/cards/forest-art.jpg"></v-img>
          <v-card-text>
            <h2 class="text-h6 text-primary">
              Magento Forests
            </h2>
          </v-card-text>
          <v-overlay
            :model-value="isHovering"
            class="align-center justify-center"
            scrim="#036358"
            contained
          >
            <v-btn variant="flat">See more info</v-btn>
          </v-overlay>
          </v-card>
         </v-hover>
       </v-col>
       <v-col md="3" cols="12">
        <v-hover v-slot="{ isHovering, props }">
        <v-card
          class="mx-auto"
          max-width="344"
          v-bind="props"
        >
          <v-img src="https://cdn.vuetifyjs.com/images/cards/forest-art.jpg"></v-img>
          <v-card-text>
            <h2 class="text-h6 text-primary">
              Magento Forests
            </h2>
          </v-card-text>
          <v-overlay
            :model-value="isHovering"
            class="align-center justify-center"
            scrim="#036358"
            contained
          >
            <v-btn variant="flat">See more info</v-btn>
          </v-overlay>
          </v-card>
         </v-hover>
       </v-col>
       <v-col md="3" cols="12">
        <v-hover v-slot="{ isHovering, props }">
        <v-card
          class="mx-auto"
          max-width="344"
          v-bind="props"
        >
          <v-img src="https://cdn.vuetifyjs.com/images/cards/forest-art.jpg"></v-img>
          <v-card-text>
            <h2 class="text-h6 text-primary">
              Magento Forests
            </h2>
          </v-card-text>
          <v-overlay
            :model-value="isHovering"
            class="align-center justify-center"
            scrim="#036358"
            contained
          >
            <v-btn variant="flat">See more info</v-btn>
          </v-overlay>
          </v-card>
         </v-hover>
       </v-col>
       <v-col md="3" cols="12">
        <v-hover v-slot="{ isHovering, props }">
        <v-card
          class="mx-auto"
          max-width="344"
          v-bind="props"
        >
          <v-img src="https://cdn.vuetifyjs.com/images/cards/forest-art.jpg"></v-img>
          <v-card-text>
            <h2 class="text-h6 text-primary">
              Magento Forests
            </h2>
          </v-card-text>
          <v-overlay
            :model-value="isHovering"
            class="align-center justify-center"
            scrim="#036358"
            contained
          >
            <v-btn variant="flat">See more info</v-btn>
          </v-overlay>
          </v-card>
         </v-hover>
       </v-col>
       <v-col md="3" cols="12">
        <v-hover v-slot="{ isHovering, props }">
        <v-card
          class="mx-auto"
          max-width="344"
          v-bind="props"
        >
          <v-img src="https://cdn.vuetifyjs.com/images/cards/forest-art.jpg"></v-img>
          <v-card-text>
            <h2 class="text-h6 text-primary">
              Magento Forests
            </h2>
          </v-card-text>
          <v-overlay
            :model-value="isHovering"
            class="align-center justify-center"
            scrim="#036358"
            contained
          >
            <v-btn variant="flat">See more info</v-btn>
          </v-overlay>
          </v-card>
         </v-hover>
       </v-col>
       <v-col md="3" cols="12">
        <v-hover v-slot="{ isHovering, props }">
        <v-card
          class="mx-auto"
          max-width="344"
          v-bind="props"
        >
          <v-img src="https://cdn.vuetifyjs.com/images/cards/forest-art.jpg"></v-img>
          <v-card-text>
            <h2 class="text-h6 text-primary">
              Magento Forests
            </h2>
          </v-card-text>
          <v-overlay
            :model-value="isHovering"
            class="align-center justify-center"
            scrim="#036358"
            contained
          >
            <v-btn variant="flat">See more info</v-btn>
          </v-overlay>
          </v-card>
         </v-hover>
       </v-col>
    </v-row>

  </template> -->

  <template>
    <v-container class="bg-about" fluid>
      <v-data-iterator
        :items="project"
        :items-per-page="itemsPerPage"
      >
        <template v-slot:header="{ page, pageCount, prevPage, nextPage }">
          <h1 class="text-md-h4 font-weight-bold d-flex justify-space-between ma-md-16  my-6 align-center">
            <div class="text-truncate text-indigo-lighten-1 text-h6 text-md-h4"  data-aos="fade-right" data-aos-duration="2000">
              My Project
            </div>
            <div class="d-flex align-center" data-aos="fade-left" data-aos-duration="2000">
              <v-btn
                class="me-8"
                variant="text"
                @click="onClickSeeAll"
              >
                <span class="text-decoration-underline text-none">{{value}}</span>
              </v-btn>
              <div class="d-inline-flex">
                <v-btn
                  :disabled="page === 1"
                  class="me-2"
                  icon="mdi-arrow-left"
                  size="small"
                  variant="tonal"
                  @click="prevPage"
                ></v-btn>
                <v-btn
                  :disabled="page === pageCount"
                  icon="mdi-arrow-right"
                  size="small"
                  variant="tonal"
                  @click="nextPage"
                ></v-btn>
              </div>
            </div>
          </h1>
        </template>
        <template v-slot:default="{ items }">
          <v-row class="w-md-75 mx-auto mt-md-16 pt-16" align="center" justify="center">
            <v-col
              v-for="(item, i) in items"
              :key="i"
              cols="12"
              md="4"
            >
              <v-sheet class="bg-about"  data-aos="zoom-in"
              data-aos-duration="1000"
              data-aos-offset="200"
              data-aos-easing="ease-in-out">
                <v-hover v-slot="{ isHovering, props }">
                  <v-card
                  rounded="xl"
                    class="mx-auto pa-0 text-h5 bg-about"
                    max-width="344"
                    height="300"
                    v-bind="props"
                    variant="flat"
                  >
                <v-img
                  :src="item.raw.src"
                  height="250"
                  cover
                  rounded="xl"
                ></v-img>
                <v-list-item
                  :title="item.raw.name"
                  density="comfortable"
                  class="py-0 text-center"
                >
                </v-list-item>
                <v-overlay
                :model-value="isHovering"
                class="align-center justify-center"
                scrim="black"
                contained
              >
                  <a :href="item.raw.code" target="_blank"> <v-icon color="deep-purple-lighten-4" size="x-large" class="mx-2" icon="mdi-xml">
                  </v-icon></a>
                <a  :href="item.raw.demo" target="_blank">
                  <v-icon color="deep-purple-lighten-4" size="x-large" class="mx-2">
                    mdi-eye</v-icon>
                </a>
              </v-overlay>
                  </v-card>
                  </v-hover>
              </v-sheet>
            </v-col>
          </v-row>
        </template>
        <template v-slot:footer="{ page, pageCount }">
          <v-footer
            class="justify-center text-center bg-deep-purple-lighten-5 mt-4 mb-md-16 w-md-75 mx-auto text-h6"
          ><v-row align="center" justify="center" >
            <v-col cols="12" md="3">
              Total Project:
                <span class="text-indigo mx-3">{{ project.length }}</span>
            </v-col>
              <v-col cols="12" md="3" >
                 Page:
                <span class="text-indigo  mx-2">{{ page }}</span>  of {{ pageCount }}
              </v-col>
          </v-row>
          </v-footer>
        </template>
      </v-data-iterator>
    </v-container>
  </template>

  <script>
  export default {
    data () {
      return {
        itemsPerPage: 6,
        value:"SeeAll",
        project: [
          {
            name:'Portfolio',
            color:'14, 151, 210',
            src:'/images/Screenshot (402).png',
            code:'https://github.com/Mariam-Rasho/Portfolio-Mariam',
            demo:'https://portfolio-mariam-iota.vercel.app/',
          },
          {
            name: 'E-Commerce',
            color: '14, 151, 210',
            src: '/images/Screenshot (361).png',
            code:"https://github.com/Mariam-Rasho/angle-store",
            demo:"https://angle-store.vercel.app/",
          },
          {
            name: 'Todo-List',
            color: '12, 146, 47',
            src: '/images/Screenshot (363).png',
            code:"https://github.com/Mariam-Rasho/Todo-List",
            demo:"https://mariam-rasho.github.io/Todo-List/",
          },
          {
            name: 'Scholar',
            color: '107, 187, 226',
            src: '/images/Screenshot (364).png',
            code:"https://github.com/Mariam-Rasho/Scholar",
            demo:"https://mariam-rasho.github.io/Scholar/"
          },
          {
            name: 'Form-AddUser',
            color: '228, 196, 69',
            src: '/images/Screenshot (367).png',
            code:"https://github.com/Mariam-Rasho/form-js",
            demo:"https://mariam-rasho.github.io/form-js/"
          },
          {
            name: 'Stop Watch',
            color: '156, 82, 251',
            src: '/images/Screenshot (369).png',
            code:"https://github.com/Mariam-Rasho/stopwatch",
            demo:"https://mariam-rasho.github.io/stopwatch/"
          },
          {
            name: 'Disney',
            color: '166, 39, 222',
            src: '/images/Screenshot (373).png',
            code:"https://github.com/Mariam-Rasho/homwork-fech-api-",
            demo:"https://mariam-rasho.github.io/homwork-fech-api-/"
          },
          {
            name: 'SEO-Project',
            color: '131, 9, 10',
            src: '/images/Screenshot (384).png',
            code:"https://github.com/Mariam-Rasho/SEOBizz",
            demo:"https://mariam-rasho.github.io/SEOBizz/"
          },
          {
            name: 'Form_Sign-UP',
            color: '232, 94, 102',
            src: '/images/Screenshot (386).png',
            code:"https://github.com/Mariam-Rasho/Form_Sign-UP/",
            demo:"https://mariam-rasho.github.io/Form_Sign-UP/"
          },
          {
            name: 'Bulma_project',
            color: '58, 192, 239',
            src: '/images/Screenshot (388).png',
            code:"https://github.com/Mariam-Rasho/bulma_project",
            demo:"https://mariam-rasho.github.io/bulma_project/"
          },
          {
            name: 'Earth-rotation',
            color: '161, 252, 250',
            src: '/images/Screenshot (391).png',
            code:"https://github.com/Mariam-Rasho/Earth-rotation",
            demo:"https://mariam-rasho.github.io/Earth-rotation/"
          },

        ],
      }
    },
    methods: {
      onClickSeeAll () {
        this.itemsPerPage = this.itemsPerPage === 6 ? this.project.length : 6;
        this.value=this.value =="SeeLess" ? "SeeAll" :"SeeLess";
      },
    },
  }
</script>