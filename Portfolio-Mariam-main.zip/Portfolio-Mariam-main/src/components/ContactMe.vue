<template>
    <v-container class="fill-height bg-about" fluid>
      <v-responsive class="fill-height">
          <div class="py-md-14 pt-10 text-center" data-aos="zoom-in" data-aos-duration="2000">
             <p class="text-h6">Contact Me</p>
          <h1  class="text-md-h2 font-weight-bold text-indigo-lighten-1 my-6">Get In Touch</h1>
          </div>
          <v-row align="center"  class="text-h6  w-md-75 mx-auto" justify="center" data-aos="fade-up" data-aos-duration="2000">
            <v-col cols="12" md="4" class="text-start mt-md-0 mt-16">
          <h1 class="mb-2 text-h6 mx-3 mb-5">location :</h1>
          <v-icon icon="mdi mdi-map-marker" class="text-indigo-lighten-1"></v-icon>
                Damascus/Syria
            </v-col>
            <v-col cols="12" md="4" class="text-start mt-md-0 mt-16">
          <h1 class="mb-2 text-h6 mx-3 mb-5">call me :</h1>
              <v-icon icon="mdi mdi-phone" class="text-indigo-lighten-1"></v-icon>
               +963 964 632 974
            </v-col>
            <v-col cols="12" md="4" class="text-start mt-md-0 mt-16">
          <h1 class="mb-2 text-h6 mx-3 mb-5">E-Mail :</h1>
              <v-icon icon="mdi mdi-email" class="text-indigo-lighten-1"></v-icon>
              <a href="mailto:rashomariam242@gmail.com" class="text-black" >rashomariam242@gmail.com</a>
            </v-col>
            <v-col cols="12" md="4" class="text-start mt-16">
              <h1 class="mb-2 text-h6 mx-3 mb-5">GitHub :</h1>
                  <v-icon icon="mdi mdi-github" class="text-indigo-lighten-1"></v-icon>
                  <a  href="https://github.com/Mariam-Rasho/" class="text-black" > github.com/MariamRasho</a>
                </v-col><v-col cols="12" md="4" class="text-start mt-16">
                  <h1 class="mb-2 text-h6 mx-3 mb-5">LinkedIn :</h1>
                      <v-icon icon="mdi mdi-linkedin" class="text-indigo-lighten-1"></v-icon>
                      <a href="https://www.linkedin.com/in/mariam-rasho-4388241b5/" class="text-black" >linkedin.com/in/MariamRasho</a>
                    </v-col>

          </v-row>
        <!-- </v-col> -->
      <!-- </v-row> -->

      </v-responsive>
    </v-container>
  </template>

  <script setup>

  </script>
<style>
.bg-about{
  background-color: rgb(245, 231, 255) !important;

}
</style>