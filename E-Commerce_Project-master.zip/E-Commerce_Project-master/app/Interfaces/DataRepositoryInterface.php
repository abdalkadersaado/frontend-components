<?php

namespace App\Interfaces;

interface DataRepositoryInterface
{
    public function abilities();

}
